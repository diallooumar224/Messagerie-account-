import React, { useState } from 'react';
import { signup } from './api';

export default function Signup({ onSignup }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [message, setMessage] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    const res = await signup(username, password);
    if (res.message === 'Inscription réussie') {
      setMessage('Compte créé ! Connectez-vous.');
      onSignup();
    } else {
      setMessage(res.message);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>Créer un compte</h2>
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Nom d'utilisateur" required />
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Mot de passe" required />
      <button type="submit">S’inscrire</button>
      <p>{message}</p>
    </form>
  );
}