import React, { useEffect, useState } from 'react';
import { io } from 'socket.io-client';

export default function Chat({ token }) {
  const [socket, setSocket] = useState(null);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const s = io('http://localhost:5000', { auth: { token } });
    setSocket(s);
    s.on('message', msg => setMessages(msgs => [...msgs, msg]));
    return () => s.disconnect();
  }, [token]);

  const sendMessage = () => {
    if (input.trim()) {
      socket.emit('message', input);
      setInput('');
    }
  };

  return (
    <div>
      <h2>Messagerie instantanée</h2>
      <div style={{ border: '1px solid #ccc', height: 200, overflow: 'auto' }}>
        {messages.map((m, i) => <div key={i}><b>{m.user} :</b> {m.text}</div>)}
      </div>
      <input value={input} onChange={e => setInput(e.target.value)} placeholder="Message..." />
      <button onClick={sendMessage}>Envoyer</button>
    </div>
  );
}