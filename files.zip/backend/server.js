const express = require('express');
const http = require('http');
const cors = require('cors');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const socketIo = require('socket.io');
const User = require('./models/User');
const auth = require('./middlewares/auth');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());

// Connexion MongoDB
mongoose.connect('mongodb://localhost:27017/secure-chat', { useNewUrlParser: true, useUnifiedTopology: true });

// Inscription
app.post('/api/signup', async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ message: 'Champs requis manquants' });
  const exists = await User.findOne({ username });
  if (exists) return res.status(400).json({ message: 'Utilisateur déjà existant' });
  const hashed = await bcrypt.hash(password, 10);
  const user = new User({ username, password: hashed });
  await user.save();
  res.json({ message: 'Inscription réussie' });
});

// Connexion
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  const user = await User.findOne({ username });
  if (!user) return res.status(400).json({ message: 'Identifiants invalides' });
  const valid = await bcrypt.compare(password, user.password);
  if (!valid) return res.status(400).json({ message: 'Identifiants invalides' });
  const token = jwt.sign({ userId: user._id, username: user.username }, 'SECRET_KEY');
  res.json({ token, username: user.username });
});

// Profil utilisateur (protégé)
app.get('/api/profile', auth, async (req, res) => {
  const user = await User.findById(req.userId).select('-password');
  res.json(user);
});

// Socket.io pour la messagerie instantanée
io.use((socket, next) => {
  const token = socket.handshake.auth.token;
  if (!token) return next(new Error('Authentication error'));
  try {
    const payload = jwt.verify(token, 'SECRET_KEY');
    socket.userId = payload.userId;
    socket.username = payload.username;
    next();
  } catch (err) {
    next(new Error('Authentication error'));
  }
});

io.on('connection', (socket) => {
  socket.on('message', (msg) => {
    // Diffuse à tous les clients connectés
    io.emit('message', { user: socket.username, text: msg, date: new Date().toISOString() });
  });
});

server.listen(5000, () => console.log('Server running on http://localhost:5000'));